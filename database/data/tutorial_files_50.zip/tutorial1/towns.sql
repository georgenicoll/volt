CREATE TABLE towns (
   town VARCHAR(128),
   county VARCHAR(64),
   state VARCHAR(2)
);

